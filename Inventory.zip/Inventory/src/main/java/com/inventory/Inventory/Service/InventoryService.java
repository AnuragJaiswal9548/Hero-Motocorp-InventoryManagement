package com.inventory.Inventory.Service;

public interface InventoryService {
    public void addRecords(String upiCode, String partNumber, String partName);

   public boolean findIfPresent(String partNumber, String upiCode);

    boolean checkByPartNumber(String uniPartNumber);

    public void deleteItem(String upiCode, String partNumber);

    String findPartNameByPartNumber(String partNumber);

    boolean findByUPICodeAndParNumber(String uniUpICode, String uniPartNumber);
//    public int checkIfPresent(String upiCode, String partNumber);
}
